class PagesController < ApplicationController
  # def index
  #   if user_signed_in?
  #     @machines = Machine.where(user_id: current_user.id)
  #   end
    
  # end
end
