module MachineHelper
end
