module Deeploy
  VERSION = '0.1.46'
end
