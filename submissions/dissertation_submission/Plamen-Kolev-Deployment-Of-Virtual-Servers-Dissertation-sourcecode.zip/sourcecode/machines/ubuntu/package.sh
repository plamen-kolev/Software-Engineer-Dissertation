rm ubuntu.box && vagrant package --output ubuntu.box && vagrant box add plamen-kolev/ubuntu ubuntu.box
