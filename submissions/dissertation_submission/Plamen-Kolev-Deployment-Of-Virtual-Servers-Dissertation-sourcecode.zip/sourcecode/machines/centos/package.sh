rm centos.box && vagrant package --output centos.box && vagrant box add --force plamen-kolev/centos centos.box
